import re
code = raw_input("Enter code: ")
num_items = int(raw_input("How many trials on the survey? "))
survey_name = raw_input("What do you want to call the output file? ")
header = re.sub("<CODE>", code, """

<script type="text/javascript"> 

function stopRKey(evt) { 
  var evt = (evt) ? evt : ((event) ? event : null); 
  var node = (evt.target) ? evt.target : ((evt.srcElement) ? evt.srcElement : null); 
  if ((evt.keyCode == 13) && (node.type=="text"))  {return false;} 
} 

document.onkeypress = stopRKey; 

</script>

<h1>Sentence understanding</h1>

<p>&nbsp;</p>

<p><font color="red"><b>SURVEY CODE:<CODE> </b></font></p>


<p><font color="red"><i><b>PLEASE COMPLETE ONLY ONE&nbsp;</b><b>SURVEY WITH CODE </b><b><CODE></b><b>.&nbsp; YOU WILL NOT BE PAID FOR COMPLETING MORE THAN ONE SURVEY WITH THIS CODE.</b></i></font></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>Consent Statement<br />
<br />
By answering the following questions, you are participating in a study being performed by cognitive scientists in the MIT Department of Brain and Cognitive Science. If you have questions about this research, please contact Edward Gibson at egibson@mit.edu. Your participation in this research is voluntary. You may decline to answer any or all of the following questions. You may decline further participation, at any time, without adverse consequences. Your anonymity is assured; the researchers who have requested your participation will not receive any personal information about you.&nbsp;</p>

<p>Please answer the background questions below. The only restriction to being paid is achieving the accuracy requirements listed below. Payment is NOT dependent on your answers to the following background questions on country and language.</p>

<p>What country are you from? <input name="country" type="radio" value="USA" /><span class="answertext">USA </span>&nbsp;&nbsp;&nbsp; <input name="country" type="radio" value="CAN" /><span class="answertext">Canada</span>&nbsp; &nbsp; <input name="country" type="radio" value="UK" /><span class="answertext">UK &nbsp; &nbsp; </span><input name="country" type="radio" value="AUS" />Australia / New Zealand &nbsp;&nbsp;&nbsp;&nbsp;<input name="country" type="radio" value="IND" /><span class="answertext">India&nbsp; &nbsp; </span><input name="country" type="radio" value="OTHER" /><span class="answertext">Other&nbsp;&nbsp;</span></p>

<p>Is English your first language? <input name="English" type="radio" value="yes" /><span class="answertext"> Yes </span>&nbsp;&nbsp;&nbsp;<input name="English" type="radio" value="no" /><span class="answertext">No</span></p>

<h2>Instructions</h2>

<p><i>Please read each sentence, and then answer the question immediately following.</i></p>

<p><b>Please note that there are correct answers for many questions.</b></p>

<p>Because some Mechanical Turk users answer questions randomly, we will reject users with error rates of 25% or larger.&nbsp; Consequently, if you cannot answer 75% of the questions correctly, please do not fill out the survey.<br />
<br />
---------------------------------------------------------------------------------------------------------------</p>""")

f = open(survey_name, "w")
f.write(header + "\n")

for i in range(1, num_items + 1):
    f.write("""<p id="${code__%(num)s}__%(num)s"><b>Sentence:</b> ${trial__%(num)s}</p>
    <p ><b>Question:</b> ${question__%(num)s}</p>
<p><input type="radio" value="Yes" name="YNQ__%(num)s" /><span class="answertext">Yes &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <input type="radio" value="No" name="YNQ__%(num)s" />No</span></p>
<p>Sentence rating:</p>
<p><input type="radio" value="1" name="Rating__%(num)s" /><span class="answertext">Extremely unnatural &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <input type="radio" value="2" name="Rating__%(num)s"  /><span class="answertext"> Somewhat unnatural&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <input type="radio" value="3" name="Rating__%(num)s" /><span class="answertext"> Possible &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <input type="radio" value="4" name="Rating__%(num)s"  /><span class="answertext"> Somewhat natural &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <input type="radio" value="5" name="Rating__%(num)s"  /><span class="answertext"> Extremely natural</span></span></span></span></span></p>
<p>---------------------------------------------------------------------------------------------------------------</p>""" %{"num":i})
    f.write("\n")

f.write("""<p>---------------------------------------------------------------------------------------------------------------</p>
<p><b><br />
</b>Please leave any comments here.</p>
<p><textarea name="answer" cols="80" rows="3"></textarea></p>""")

f.close()
