library(reshape)
library(dplyr)
library(ggplot2)
library(plotrix)
library(lme4)

#variables of subject information asked for
#change the following:
results.file = 'Batch_1846232_batch_results.csv'
maxna = .1 # maximum permitted proportion of NA responses per rating question
mincorrect = .75 # minimum permitted proportion of correct responses to comprehension questions
num.trials = 16  # maximum number of trials per participant

d = read.csv(results.file, colClasses = 'character') 

#only keep WorkerId and cols that Start with Answer or Input
d = d[, grep("(^Input)|(^Answer)|WorkerId", names(d))]

#reshape
d.melt <- melt(d, id.vars = c('WorkerId', 'Answer.English', 'Answer.answer', 'Answer.country', 'Input.list'))
d.melt <- cbind(d.melt, colsplit(d.melt$variable, split="__", names=c('v', 'order')))
d <- cast(d.melt, WorkerId + Answer.English + Answer.answer + Answer.country + Input.list + order ~ v)

#split into experiment, conditino, item, correct.answer
d <- cbind(d, colsplit(d$Input.code, split="_", names=c('experiment', 'condition', 'item', 'correct.answer')))

##make all characters and set answer rating to numeric
d <- data.frame(lapply(d, as.character), stringsAsFactors=FALSE)
d$Answer.Rating <- as.numeric(d$Answer.Rating)
d$Correct <- d$correct.answer == d$Answer.YNQ

z_score = function(xs) {
    (xs - mean(xs)) / sd(xs)
}

##Add participant correct and na, z score ratings
d = group_by(d, WorkerId) %>%
    mutate(na.pct = mean(is.na(Answer.Rating)),
           correct.pct = mean(Correct),
           n = length(Answer.Rating)) %>%
    ungroup()
                

#filter for US, English, na, and correct and duplicate
d = d %>%
    filter(na.pct <= maxna &
           correct.pct >= mincorrect &
           Answer.English == "yes" &
           Answer.country == "USA" &
           n <= num.trials) %>%
    filter(!is.na(Answer.Rating))

d = d %>% group_by(WorkerId) %>% mutate(participant.z=z_score(Answer.Rating)) %>% ungroup()

############################################################################
